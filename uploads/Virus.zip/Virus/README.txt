if you went to download virus, install __________
                                       KabriVirus
                                       ----------


if you went to delete this virus, you need to reset your pc(reset pc(delete all files)).